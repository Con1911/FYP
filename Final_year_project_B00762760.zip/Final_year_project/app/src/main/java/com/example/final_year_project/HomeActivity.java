package com.example.final_year_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {
    Button button, button2, button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        TextView txtname = (TextView) findViewById(R.id.textView_success);
        Intent intent = getIntent();
        String loginName = intent.getStringExtra("Name");
        txtname.setText("Welcome, " + loginName);


        button = (Button) findViewById(R.id.button_generate_program);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, EnterInfo.class);
                startActivity(intent);
            }
        });

        button2 = (Button) findViewById(R.id.button_myWorkouts);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, MyWorkouts.class);
                startActivity(intent);
            }
        });

        button3 = (Button) findViewById(R.id.button_exercises);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, HelpPage.class);
                startActivity(intent);
            }
        });


    }
    public void logOutOk(View view){
        Intent intent = new Intent( HomeActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}