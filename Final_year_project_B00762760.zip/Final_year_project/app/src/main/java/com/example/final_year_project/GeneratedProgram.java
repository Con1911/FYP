package com.example.final_year_project;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import java.util.List;

public class GeneratedProgram extends AppCompatActivity {


    Button button, button2, buttonHome;
    TextView wkt1, wkt2, wkt3, wkt4, wkt5, set1, set2, set3, set4, set5, rep1, rep2, rep3, rep4, rep5, timerTmp;
    TextView workoutName, exercise1, exercise2, exercise3, exercise4, exercise5, weights1, weights2, weights3, weights4, weights5, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13, s14, s15, s16, s17, s18, s19, s20;
    String wName, ex1, ex2, ex3, ex4, ex5, wt1, wt2, wt3, wt4, wt5, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, test;
    public int counter = 0;
    public int counter2 = 0;
    public CountDownTimer myCountDownTimer;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generated_program);

        button = findViewById(R.id.startTimerBtn);
        button2 = findViewById(R.id.saveWKTbtn);
        timerTmp = findViewById(R.id.timer);
        String userName = ParseUser.getCurrentUser().getUsername();

        boolean var1B = this.getIntent().getExtras().getBoolean("variable1B");
        boolean var2B = this.getIntent().getExtras().getBoolean("variable2B");
        boolean var3B = this.getIntent().getExtras().getBoolean("variable3B");
        boolean var4B = this.getIntent().getExtras().getBoolean("variable4B");
        boolean var5B = this.getIntent().getExtras().getBoolean("variable5B");
        boolean var6B = this.getIntent().getExtras().getBoolean("variable6B");

        boolean var1A = this.getIntent().getExtras().getBoolean("variable1A");
        boolean var2A = this.getIntent().getExtras().getBoolean("variable2A");
        boolean var3A = this.getIntent().getExtras().getBoolean("variable3A");
        boolean var4A = this.getIntent().getExtras().getBoolean("variable4A");
        boolean var5A = this.getIntent().getExtras().getBoolean("variable5A");
        boolean var6A = this.getIntent().getExtras().getBoolean("variable6A");

        if (var1B){
            GetHypertrophy1();
        } else if(var2B) {
            GetHypertrophy2();
        } else if(var3B) {
            GetHypertrophy3();
        } else if(var4B) {
            GetHypertrophy4();
        } else if(var5B) {
            GetHypertrophy5();
        } else if(var6B) {
            GetHypertrophy6();
        } else if (var1A){
            GetHypertrophy1A();
        } else if(var2A) {
            GetHypertrophy2A();
        } else if(var3A) {
            GetHypertrophy3A();
        } else if(var4A) {
            GetHypertrophy4A();
        } else if(var5A) {
            GetHypertrophy5A();
        } else if(var6A) {
            GetHypertrophy6A();
        }

        buttonHome = (Button)findViewById(R.id.buttonHome2);
        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (GeneratedProgram.this, HomeActivity.class);
                startActivity(intent);
            }
        });






        //Timer
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myCountDownTimer = new CountDownTimer(120000, 1000) {
                    public void onTick(long millisUntilFinished) {
                        if (counter2 != 2) {
                            timerTmp.setText(String.valueOf("00:0" + counter));
                            if (counter >= 10) {
                                timerTmp.setText(String.valueOf("00:" + counter));
                            }
                            if (counter >= 60) {
                                counter = 0;
                                counter2++;
                            }
                            if (counter2 == 1){
                                timerTmp.setText(String.valueOf("01:0" + counter));
                                if (counter >= 10) {
                                    timerTmp.setText(String.valueOf("01:" + counter));
                                }
                                if (counter == 50){
                                    playSound();
                                }
                            }
                            counter++;
                        }
                    }

                    public void onFinish() {
                        timerTmp.setText("REST FINISHED");
                        button.setText("Restart Timer");
                    }
                }.start();
                counter = 0;
                counter2 = 0;
            }
        });


        //save workout
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                workoutName = findViewById(R.id.Exercise_title);
                wName = workoutName.getText().toString();

                exercise1 = findViewById(R.id.exerciseExple1);
                exercise2 = findViewById(R.id.exerciseExple2);
                exercise3 = findViewById(R.id.exerciseExple3);
                exercise4 = findViewById(R.id.exerciseExple4);
                exercise5 = findViewById(R.id.exerciseExple5);

                ex1 = exercise1.getText().toString();
                ex2 = exercise2.getText().toString();
                ex3 = exercise3.getText().toString();
                ex4 = exercise4.getText().toString();
                ex5 = exercise5.getText().toString();

                weights1 = findViewById(R.id.weight1);
                weights2 = findViewById(R.id.weight2);
                weights3 = findViewById(R.id.weight3);
                weights4 = findViewById(R.id.weight4);
                weights5 = findViewById(R.id.weight5);
                wt1 = weights1.getText().toString();
                wt2 = weights2.getText().toString();
                wt3 = weights3.getText().toString();
                wt4 = weights4.getText().toString();
                wt5 = weights5.getText().toString();

                s1 = findViewById(R.id.rp1_1);
                s2 = findViewById(R.id.rp2_1);
                s3 = findViewById(R.id.rp3_1);
                s4 = findViewById(R.id.rp4_1);
                r1 = s1.getText().toString();
                r2 = s2.getText().toString();
                r3 = s3.getText().toString();
                r4 = s4.getText().toString();

                s5 = findViewById(R.id.rp1_2);
                s6 = findViewById(R.id.rp2_2);
                s7 = findViewById(R.id.rp3_2);
                s8 = findViewById(R.id.rp4_2);
                r5 = s5.getText().toString();
                r6 = s6.getText().toString();
                r7 = s7.getText().toString();
                r8 = s8.getText().toString();

                s9 = findViewById(R.id.rp1_3);
                s10 = findViewById(R.id.rp2_3);
                s11 = findViewById(R.id.rp3_3);
                s12 = findViewById(R.id.rp4_3);
                r9 = s9.getText().toString();
                r10 = s10.getText().toString();
                r11 = s11.getText().toString();
                r12 = s12.getText().toString();

                s13 = findViewById(R.id.rp1_4);
                s14 = findViewById(R.id.rp2_4);
                s15 = findViewById(R.id.rp3_4);
                s16 = findViewById(R.id.rp4_4);
                r13 = s13.getText().toString();
                r14 = s14.getText().toString();
                r15 = s15.getText().toString();
                r16 = s16.getText().toString();

                s17 = findViewById(R.id.rp1_5);
                s18 = findViewById(R.id.rp2_5);
                s19 = findViewById(R.id.rp3_5);
                s20 = findViewById(R.id.rp4_5);
                r17 = s17.getText().toString();
                r18 = s18.getText().toString();
                r19 = s19.getText().toString();
                r20 = s20.getText().toString();

                AddData(userName, wName, ex1, ex2, ex3, ex4, ex5, wt1, wt2, wt3, wt4, wt5, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20);
            }
        });

    }

    //play sound method
    public void playSound() {
        MediaPlayer mp = MediaPlayer.create(GeneratedProgram.this, (R.raw.music));
        mp.start();
    }

    //get data for workout 1
    public void GetHypertrophy1(){
        wkt1 = findViewById(R.id.exerciseExple1);
        wkt2 = findViewById(R.id.exerciseExple2);
        wkt3 = findViewById(R.id.exerciseExple3);
        wkt4 = findViewById(R.id.exerciseExple4);
        wkt5 = findViewById(R.id.exerciseExple5);
        set1 = findViewById(R.id.sets1);
        set2 = findViewById(R.id.sets2);
        set3 = findViewById(R.id.sets3);
        set4 = findViewById(R.id.sets4);
        set5 = findViewById(R.id.sets5);
        rep1 = findViewById(R.id.reps1);
        rep2 = findViewById(R.id.reps2);
        rep3 = findViewById(R.id.reps3);
        rep4 = findViewById(R.id.reps4);
        rep5 = findViewById(R.id.reps5);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "AVdwKDJmhU");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise2");
                        String workout3 = objects.get(i).getString("exercise3");
                        String workout4 = objects.get(i).getString("exercise4");
                        String workout5 = objects.get(i).getString("exercise5");
                        String sets1 = objects.get(i).getString("sets2");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String sets4 = objects.get(i).getString("sets2");
                        String sets5 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("repRange3");
                        String reps2 = objects.get(i).getString("repRange2");
                        String reps3 = objects.get(i).getString("repRange2");
                        String reps4 = objects.get(i).getString("repRange1");
                        String reps5 = objects.get(i).getString("repRange3");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        wkt4.setText(workout4);
                        wkt5.setText(workout5);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        set4.setText(sets4);
                        set5.setText(sets5);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                        rep4.setText(reps4);
                        rep5.setText(reps5);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }



    private void GetHypertrophy2(){
        wkt1 = findViewById(R.id.exerciseExple1);
        wkt2 = findViewById(R.id.exerciseExple2);
        wkt3 = findViewById(R.id.exerciseExple3);
        wkt4 = findViewById(R.id.exerciseExple4);
        wkt5 = findViewById(R.id.exerciseExple5);
        set1 = findViewById(R.id.sets1);
        set2 = findViewById(R.id.sets2);
        set3 = findViewById(R.id.sets3);
        set4 = findViewById(R.id.sets4);
        set5 = findViewById(R.id.sets5);
        rep1 = findViewById(R.id.reps1);
        rep2 = findViewById(R.id.reps2);
        rep3 = findViewById(R.id.reps3);
        rep4 = findViewById(R.id.reps4);
        rep5 = findViewById(R.id.reps5);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "Govub5N6iZ");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise2");
                        String workout3 = objects.get(i).getString("exercise3");
                        String workout4 = objects.get(i).getString("exercise4");
                        String workout5 = objects.get(i).getString("exercise5");
                        String sets1 = objects.get(i).getString("sets2");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String sets4 = objects.get(i).getString("sets2");
                        String sets5 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("repRange3");
                        String reps2 = objects.get(i).getString("repRange2");
                        String reps3 = objects.get(i).getString("repRange2");
                        String reps4 = objects.get(i).getString("repRange1");
                        String reps5 = objects.get(i).getString("repRange3");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        wkt4.setText(workout4);
                        wkt5.setText(workout5);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        set4.setText(sets4);
                        set5.setText(sets5);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                        rep4.setText(reps4);
                        rep5.setText(reps5);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void GetHypertrophy3(){
        wkt1 = findViewById(R.id.exerciseExple1);
        wkt2 = findViewById(R.id.exerciseExple2);
        wkt3 = findViewById(R.id.exerciseExple3);
        wkt4 = findViewById(R.id.exerciseExple4);
        wkt5 = findViewById(R.id.exerciseExple5);
        set1 = findViewById(R.id.sets1);
        set2 = findViewById(R.id.sets2);
        set3 = findViewById(R.id.sets3);
        set4 = findViewById(R.id.sets4);
        set5 = findViewById(R.id.sets5);
        rep1 = findViewById(R.id.reps1);
        rep2 = findViewById(R.id.reps2);
        rep3 = findViewById(R.id.reps3);
        rep4 = findViewById(R.id.reps4);
        rep5 = findViewById(R.id.reps5);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "Yv3B2f8C9Y");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise2");
                        String workout3 = objects.get(i).getString("exercise3");
                        String workout4 = objects.get(i).getString("exercise4");
                        String workout5 = objects.get(i).getString("exercise5");
                        String sets1 = objects.get(i).getString("sets2");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String sets4 = objects.get(i).getString("sets2");
                        String sets5 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("repRange3");
                        String reps2 = objects.get(i).getString("repRange2");
                        String reps3 = objects.get(i).getString("repRange2");
                        String reps4 = objects.get(i).getString("repRange1");
                        String reps5 = objects.get(i).getString("repRange3");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        wkt4.setText(workout4);
                        wkt5.setText(workout5);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        set4.setText(sets4);
                        set5.setText(sets5);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                        rep4.setText(reps4);
                        rep5.setText(reps5);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void GetHypertrophy4(){
        wkt1 = findViewById(R.id.exerciseExple1);
        wkt2 = findViewById(R.id.exerciseExple2);
        wkt3 = findViewById(R.id.exerciseExple3);
        wkt4 = findViewById(R.id.exerciseExple4);
        wkt5 = findViewById(R.id.exerciseExple5);
        set1 = findViewById(R.id.sets1);
        set2 = findViewById(R.id.sets2);
        set3 = findViewById(R.id.sets3);
        set4 = findViewById(R.id.sets4);
        set5 = findViewById(R.id.sets5);
        rep1 = findViewById(R.id.reps1);
        rep2 = findViewById(R.id.reps2);
        rep3 = findViewById(R.id.reps3);
        rep4 = findViewById(R.id.reps4);
        rep5 = findViewById(R.id.reps5);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "mXTkWCdvh5");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise2");
                        String workout3 = objects.get(i).getString("exercise3");
                        String workout4 = objects.get(i).getString("exercise4");
                        String workout5 = objects.get(i).getString("exercise5");
                        String sets1 = objects.get(i).getString("sets2");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String sets4 = objects.get(i).getString("sets2");
                        String sets5 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("repRange3");
                        String reps2 = objects.get(i).getString("repRange2");
                        String reps3 = objects.get(i).getString("repRange2");
                        String reps4 = objects.get(i).getString("repRange1");
                        String reps5 = objects.get(i).getString("repRange3");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        wkt4.setText(workout4);
                        wkt5.setText(workout5);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        set4.setText(sets4);
                        set5.setText(sets5);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                        rep4.setText(reps4);
                        rep5.setText(reps5);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void GetHypertrophy5(){
        wkt1 = findViewById(R.id.exerciseExple1);
        wkt2 = findViewById(R.id.exerciseExple2);
        wkt3 = findViewById(R.id.exerciseExple3);
        wkt4 = findViewById(R.id.exerciseExple4);
        wkt5 = findViewById(R.id.exerciseExple5);
        set1 = findViewById(R.id.sets1);
        set2 = findViewById(R.id.sets2);
        set3 = findViewById(R.id.sets3);
        set4 = findViewById(R.id.sets4);
        set5 = findViewById(R.id.sets5);
        rep1 = findViewById(R.id.reps1);
        rep2 = findViewById(R.id.reps2);
        rep3 = findViewById(R.id.reps3);
        rep4 = findViewById(R.id.reps4);
        rep5 = findViewById(R.id.reps5);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "AnR9rEmDGL");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise2");
                        String workout3 = objects.get(i).getString("exercise3");
                        String workout4 = objects.get(i).getString("exercise4");
                        String workout5 = objects.get(i).getString("exercise5");
                        String sets1 = objects.get(i).getString("sets2");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String sets4 = objects.get(i).getString("sets2");
                        String sets5 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("repRange3");
                        String reps2 = objects.get(i).getString("repRange2");
                        String reps3 = objects.get(i).getString("repRange2");
                        String reps4 = objects.get(i).getString("repRange1");
                        String reps5 = objects.get(i).getString("repRange3");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        wkt4.setText(workout4);
                        wkt5.setText(workout5);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        set4.setText(sets4);
                        set5.setText(sets5);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                        rep4.setText(reps4);
                        rep5.setText(reps5);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    private void GetHypertrophy6(){
        wkt1 = findViewById(R.id.exerciseExple1);
        wkt2 = findViewById(R.id.exerciseExple2);
        wkt3 = findViewById(R.id.exerciseExple3);
        wkt4 = findViewById(R.id.exerciseExple4);
        wkt5 = findViewById(R.id.exerciseExple5);
        set1 = findViewById(R.id.sets1);
        set2 = findViewById(R.id.sets2);
        set3 = findViewById(R.id.sets3);
        set4 = findViewById(R.id.sets4);
        set5 = findViewById(R.id.sets5);
        rep1 = findViewById(R.id.reps1);
        rep2 = findViewById(R.id.reps2);
        rep3 = findViewById(R.id.reps3);
        rep4 = findViewById(R.id.reps4);
        rep5 = findViewById(R.id.reps5);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "DebnWpObdk");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise2");
                        String workout3 = objects.get(i).getString("exercise3");
                        String workout4 = objects.get(i).getString("exercise4");
                        String workout5 = objects.get(i).getString("exercise5");
                        String sets1 = objects.get(i).getString("sets2");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String sets4 = objects.get(i).getString("sets2");
                        String sets5 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("repRange3");
                        String reps2 = objects.get(i).getString("repRange2");
                        String reps3 = objects.get(i).getString("repRange2");
                        String reps4 = objects.get(i).getString("repRange1");
                        String reps5 = objects.get(i).getString("repRange3");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        wkt4.setText(workout4);
                        wkt5.setText(workout5);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        set4.setText(sets4);
                        set5.setText(sets5);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                        rep4.setText(reps4);
                        rep5.setText(reps5);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    //get data for workout 1
    public void GetHypertrophy1A(){
        wkt1 = findViewById(R.id.exerciseExple1);
        wkt2 = findViewById(R.id.exerciseExple2);
        wkt3 = findViewById(R.id.exerciseExple3);
        wkt4 = findViewById(R.id.exerciseExple4);
        wkt5 = findViewById(R.id.exerciseExple5);
        set1 = findViewById(R.id.sets1);
        set2 = findViewById(R.id.sets2);
        set3 = findViewById(R.id.sets3);
        set4 = findViewById(R.id.sets4);
        set5 = findViewById(R.id.sets5);
        rep1 = findViewById(R.id.reps1);
        rep2 = findViewById(R.id.reps2);
        rep3 = findViewById(R.id.reps3);
        rep4 = findViewById(R.id.reps4);
        rep5 = findViewById(R.id.reps5);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "AVdwKDJmhU");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise2");
                        String workout3 = objects.get(i).getString("exercise3");
                        String workout4 = objects.get(i).getString("exercise4");
                        String workout5 = objects.get(i).getString("exercise5");
                        String sets1 = objects.get(i).getString("sets1");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String sets4 = objects.get(i).getString("sets1");
                        String sets5 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("repRange3");
                        String reps2 = objects.get(i).getString("repRange2");
                        String reps3 = objects.get(i).getString("repRange2");
                        String reps4 = objects.get(i).getString("repRange1");
                        String reps5 = objects.get(i).getString("repRange3");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        wkt4.setText(workout4);
                        wkt5.setText(workout5);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        set4.setText(sets4);
                        set5.setText(sets5);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                        rep4.setText(reps4);
                        rep5.setText(reps5);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }



    private void GetHypertrophy2A(){
        wkt1 = findViewById(R.id.exerciseExple1);
        wkt2 = findViewById(R.id.exerciseExple2);
        wkt3 = findViewById(R.id.exerciseExple3);
        wkt4 = findViewById(R.id.exerciseExple4);
        wkt5 = findViewById(R.id.exerciseExple5);
        set1 = findViewById(R.id.sets1);
        set2 = findViewById(R.id.sets2);
        set3 = findViewById(R.id.sets3);
        set4 = findViewById(R.id.sets4);
        set5 = findViewById(R.id.sets5);
        rep1 = findViewById(R.id.reps1);
        rep2 = findViewById(R.id.reps2);
        rep3 = findViewById(R.id.reps3);
        rep4 = findViewById(R.id.reps4);
        rep5 = findViewById(R.id.reps5);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "Govub5N6iZ");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise2");
                        String workout3 = objects.get(i).getString("exercise3");
                        String workout4 = objects.get(i).getString("exercise4");
                        String workout5 = objects.get(i).getString("exercise5");
                        String sets1 = objects.get(i).getString("sets1");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String sets4 = objects.get(i).getString("sets1");
                        String sets5 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("repRange3");
                        String reps2 = objects.get(i).getString("repRange2");
                        String reps3 = objects.get(i).getString("repRange2");
                        String reps4 = objects.get(i).getString("repRange1");
                        String reps5 = objects.get(i).getString("repRange3");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        wkt4.setText(workout4);
                        wkt5.setText(workout5);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        set4.setText(sets4);
                        set5.setText(sets5);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                        rep4.setText(reps4);
                        rep5.setText(reps5);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void GetHypertrophy3A(){
        wkt1 = findViewById(R.id.exerciseExple1);
        wkt2 = findViewById(R.id.exerciseExple2);
        wkt3 = findViewById(R.id.exerciseExple3);
        wkt4 = findViewById(R.id.exerciseExple4);
        wkt5 = findViewById(R.id.exerciseExple5);
        set1 = findViewById(R.id.sets1);
        set2 = findViewById(R.id.sets2);
        set3 = findViewById(R.id.sets3);
        set4 = findViewById(R.id.sets4);
        set5 = findViewById(R.id.sets5);
        rep1 = findViewById(R.id.reps1);
        rep2 = findViewById(R.id.reps2);
        rep3 = findViewById(R.id.reps3);
        rep4 = findViewById(R.id.reps4);
        rep5 = findViewById(R.id.reps5);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "Yv3B2f8C9Y");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise2");
                        String workout3 = objects.get(i).getString("exercise3");
                        String workout4 = objects.get(i).getString("exercise4");
                        String workout5 = objects.get(i).getString("exercise5");
                        String sets1 = objects.get(i).getString("sets1");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String sets4 = objects.get(i).getString("sets1");
                        String sets5 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("repRange3");
                        String reps2 = objects.get(i).getString("repRange2");
                        String reps3 = objects.get(i).getString("repRange2");
                        String reps4 = objects.get(i).getString("repRange1");
                        String reps5 = objects.get(i).getString("repRange3");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        wkt4.setText(workout4);
                        wkt5.setText(workout5);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        set4.setText(sets4);
                        set5.setText(sets5);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                        rep4.setText(reps4);
                        rep5.setText(reps5);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void GetHypertrophy4A(){
        wkt1 = findViewById(R.id.exerciseExple1);
        wkt2 = findViewById(R.id.exerciseExple2);
        wkt3 = findViewById(R.id.exerciseExple3);
        wkt4 = findViewById(R.id.exerciseExple4);
        wkt5 = findViewById(R.id.exerciseExple5);
        set1 = findViewById(R.id.sets1);
        set2 = findViewById(R.id.sets2);
        set3 = findViewById(R.id.sets3);
        set4 = findViewById(R.id.sets4);
        set5 = findViewById(R.id.sets5);
        rep1 = findViewById(R.id.reps1);
        rep2 = findViewById(R.id.reps2);
        rep3 = findViewById(R.id.reps3);
        rep4 = findViewById(R.id.reps4);
        rep5 = findViewById(R.id.reps5);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "mXTkWCdvh5");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise2");
                        String workout3 = objects.get(i).getString("exercise3");
                        String workout4 = objects.get(i).getString("exercise4");
                        String workout5 = objects.get(i).getString("exercise5");
                        String sets1 = objects.get(i).getString("sets1");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String sets4 = objects.get(i).getString("sets1");
                        String sets5 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("repRange3");
                        String reps2 = objects.get(i).getString("repRange2");
                        String reps3 = objects.get(i).getString("repRange2");
                        String reps4 = objects.get(i).getString("repRange1");
                        String reps5 = objects.get(i).getString("repRange3");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        wkt4.setText(workout4);
                        wkt5.setText(workout5);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        set4.setText(sets4);
                        set5.setText(sets5);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                        rep4.setText(reps4);
                        rep5.setText(reps5);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void GetHypertrophy5A(){
        wkt1 = findViewById(R.id.exerciseExple1);
        wkt2 = findViewById(R.id.exerciseExple2);
        wkt3 = findViewById(R.id.exerciseExple3);
        wkt4 = findViewById(R.id.exerciseExple4);
        wkt5 = findViewById(R.id.exerciseExple5);
        set1 = findViewById(R.id.sets1);
        set2 = findViewById(R.id.sets2);
        set3 = findViewById(R.id.sets3);
        set4 = findViewById(R.id.sets4);
        set5 = findViewById(R.id.sets5);
        rep1 = findViewById(R.id.reps1);
        rep2 = findViewById(R.id.reps2);
        rep3 = findViewById(R.id.reps3);
        rep4 = findViewById(R.id.reps4);
        rep5 = findViewById(R.id.reps5);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "AnR9rEmDGL");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise2");
                        String workout3 = objects.get(i).getString("exercise3");
                        String workout4 = objects.get(i).getString("exercise4");
                        String workout5 = objects.get(i).getString("exercise5");
                        String sets1 = objects.get(i).getString("sets1");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String sets4 = objects.get(i).getString("sets1");
                        String sets5 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("repRange3");
                        String reps2 = objects.get(i).getString("repRange2");
                        String reps3 = objects.get(i).getString("repRange2");
                        String reps4 = objects.get(i).getString("repRange1");
                        String reps5 = objects.get(i).getString("repRange3");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        wkt4.setText(workout4);
                        wkt5.setText(workout5);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        set4.setText(sets4);
                        set5.setText(sets5);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                        rep4.setText(reps4);
                        rep5.setText(reps5);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    private void GetHypertrophy6A(){
        wkt1 = findViewById(R.id.exerciseExple1);
        wkt2 = findViewById(R.id.exerciseExple2);
        wkt3 = findViewById(R.id.exerciseExple3);
        wkt4 = findViewById(R.id.exerciseExple4);
        wkt5 = findViewById(R.id.exerciseExple5);
        set1 = findViewById(R.id.sets1);
        set2 = findViewById(R.id.sets2);
        set3 = findViewById(R.id.sets3);
        set4 = findViewById(R.id.sets4);
        set5 = findViewById(R.id.sets5);
        rep1 = findViewById(R.id.reps1);
        rep2 = findViewById(R.id.reps2);
        rep3 = findViewById(R.id.reps3);
        rep4 = findViewById(R.id.reps4);
        rep5 = findViewById(R.id.reps5);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "DebnWpObdk");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise2");
                        String workout3 = objects.get(i).getString("exercise3");
                        String workout4 = objects.get(i).getString("exercise4");
                        String workout5 = objects.get(i).getString("exercise5");
                        String sets1 = objects.get(i).getString("sets1");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String sets4 = objects.get(i).getString("sets1");
                        String sets5 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("repRange3");
                        String reps2 = objects.get(i).getString("repRange2");
                        String reps3 = objects.get(i).getString("repRange2");
                        String reps4 = objects.get(i).getString("repRange1");
                        String reps5 = objects.get(i).getString("repRange3");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        wkt4.setText(workout4);
                        wkt5.setText(workout5);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        set4.setText(sets4);
                        set5.setText(sets5);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                        rep4.setText(reps4);
                        rep5.setText(reps5);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }



    //add workout data
    public void AddData(String userName, String workoutName, String exercise1, String exercise2, String exercise3, String exercise4, String exercise5, String weights1, String weights2, String weights3, String weights4, String weights5, String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9, String s10, String s11, String s12, String s13, String s14, String s15, String s16, String s17, String s18, String s19, String s20){

        ParseObject AddExercise = new ParseObject("exercises2");
        AddExercise.put("username", userName);
        AddExercise.put("workoutName", workoutName);
        AddExercise.put("exercise1", exercise1);
        AddExercise.put("exercise2", exercise2);
        AddExercise.put("exercise3", exercise3);
        AddExercise.put("exercise4", exercise4);
        AddExercise.put("exercise5", exercise5);

        AddExercise.put("weight1", weights1);
        AddExercise.put("weight2", weights2);
        AddExercise.put("weight3", weights3);
        AddExercise.put("weight4", weights4);
        AddExercise.put("weight5", weights5);

        AddExercise.put("set1", s1);
        AddExercise.put("set2", s2);
        AddExercise.put("set3", s3);
        AddExercise.put("set4", s4);
        AddExercise.put("set5", s5);
        AddExercise.put("set6", s6);
        AddExercise.put("set7", s7);
        AddExercise.put("set8", s8);
        AddExercise.put("set9", s9);
        AddExercise.put("set10", s10);
        AddExercise.put("set11", s11);
        AddExercise.put("set12", s12);
        AddExercise.put("set13", s13);
        AddExercise.put("set14", s14);
        AddExercise.put("set15", s15);
        AddExercise.put("set16", s16);
        AddExercise.put("set17", s17);
        AddExercise.put("set18", s18);
        AddExercise.put("set19", s19);
        AddExercise.put("set20", s20);

        AddExercise.saveInBackground(new SaveCallback() {
            @Override
            public void done(ParseException e) {

                if (e == null) {
                    Toast.makeText(GeneratedProgram.this, "Workout saved!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), e.getMessage().toString(), Toast.LENGTH_LONG).show();
                }
            }
        });

    }












}

