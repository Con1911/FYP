package com.example.final_year_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class GeneratedProgramWorkouts extends AppCompatActivity {

    Button button1, button2, button3, button4, button5, button6, button7;
    String checkWorkout, checkWorkout2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generated_program_workouts);

        button1 = (Button)findViewById(R.id.day1Btn);
        button2 = (Button)findViewById(R.id.day2Btn);
        button3 = (Button)findViewById(R.id.day3Btn);
        button4 = (Button)findViewById(R.id.day4Btn);
        button5 = (Button)findViewById(R.id.day5Btn);
        button6 = (Button)findViewById(R.id.day6Btn);
        button7 = (Button)findViewById(R.id.buttonHome);

        boolean var1 = this.getIntent().getExtras().getBoolean("beginner_3days_Strength");
        boolean var2 = this.getIntent().getExtras().getBoolean("beginner, 4days, Strength");
        boolean var3 = this.getIntent().getExtras().getBoolean("beginner, 3days, Hypertrophy");
        boolean var4 = this.getIntent().getExtras().getBoolean("beginner, 4days, Hypertrophy");
        boolean var5 = this.getIntent().getExtras().getBoolean("advanced, 3days, Hypertrophy");
        boolean var6 = this.getIntent().getExtras().getBoolean("advanced, 4days, Hypertrophy");
        boolean var7 = this.getIntent().getExtras().getBoolean("advanced, 6days, Hypertrophy");
        boolean var8 = this.getIntent().getExtras().getBoolean("advanced, 3days, Strength");
        boolean var9 = this.getIntent().getExtras().getBoolean("advanced, 4days, Strength");
        boolean var10 = this.getIntent().getExtras().getBoolean("advanced, 6days, Strength");

        if (var1){
            button4.setVisibility(View.INVISIBLE);
            button5.setVisibility(View.INVISIBLE);
            button6.setVisibility(View.INVISIBLE);
            checkWorkout = "strengthB";
        } else if (var2){
            button5.setVisibility(View.INVISIBLE);
            button6.setVisibility(View.INVISIBLE);
            checkWorkout = "strengthB";
        } else if (var3){
            button4.setVisibility(View.INVISIBLE);
            button5.setVisibility(View.INVISIBLE);
            button6.setVisibility(View.INVISIBLE);
            checkWorkout2 = "hypertrophyB";
        } else if (var4){
            button5.setVisibility(View.INVISIBLE);
            button6.setVisibility(View.INVISIBLE);
            checkWorkout2 = "hypertrophyB";
        } else if (var5){
            button4.setVisibility(View.INVISIBLE);
            button5.setVisibility(View.INVISIBLE);
            button6.setVisibility(View.INVISIBLE);
            checkWorkout2 = "hypertrophyA";
        } else if (var6){
            button5.setVisibility(View.INVISIBLE);
            button6.setVisibility(View.INVISIBLE);
            checkWorkout2 = "hypertrophyA";
        } else if (var7){
            checkWorkout2 = "hypertrophyA";
        } else if (var8){
            button4.setVisibility(View.INVISIBLE);
            button5.setVisibility(View.INVISIBLE);
            button6.setVisibility(View.INVISIBLE);
            checkWorkout = "strengthA";
        } else if (var9){
            button5.setVisibility(View.INVISIBLE);
            button6.setVisibility(View.INVISIBLE);
            checkWorkout = "strengthA";
        } else if (var10){
            checkWorkout = "strengthA";
        }


        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GeneratedProgramWorkouts.this, HomeActivity.class);
                startActivity(intent);
            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (checkWorkout == "strengthB") {
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram2.class);
                    intent.putExtra("variable1_1B", true);
                    startActivity(intent);
                } else if (checkWorkout == "strengthA") {
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram2.class);
                    intent.putExtra("variable1_1A", true);
                    startActivity(intent);
                } else if (checkWorkout2 == "hypertrophyB"){
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram.class);
                    intent.putExtra("variable1B", true);
                    startActivity(intent);
                } else if (checkWorkout2 == "hypertrophyA"){
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram.class);
                    intent.putExtra("variable1A", true);
                    startActivity(intent);
                }
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (checkWorkout == "strengthB") {
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram2.class);
                    intent.putExtra("variable2_2B", true);
                    startActivity(intent);
                } else if (checkWorkout == "strengthA") {
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram2.class);
                    intent.putExtra("variable2_2A", true);
                    startActivity(intent);
                } else if (checkWorkout2 == "hypertrophyB"){
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram.class);
                    intent.putExtra("variable2B", true);
                    startActivity(intent);
                } else if (checkWorkout2 == "hypertrophyA"){
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram.class);
                    intent.putExtra("variable2A", true);
                    startActivity(intent);
                }
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (checkWorkout == "strengthB") {
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram2.class);
                    intent.putExtra("variable3_3B", true);
                    startActivity(intent);
                } else if (checkWorkout == "strengthA") {
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram2.class);
                    intent.putExtra("variable3_3A", true);
                    startActivity(intent);
                } else if (checkWorkout2 == "hypertrophyB"){
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram.class);
                    intent.putExtra("variable3B", true);
                    startActivity(intent);
                } else if (checkWorkout2 == "hypertrophyA"){
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram.class);
                    intent.putExtra("variable3A", true);
                    startActivity(intent);
                }
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (checkWorkout == "strengthB") {
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram2.class);
                    intent.putExtra("variable4_4B", true);
                    startActivity(intent);
                } else if (checkWorkout == "strengthA") {
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram2.class);
                    intent.putExtra("variable4_4A", true);
                    startActivity(intent);
                } else if (checkWorkout2 == "hypertrophyB"){
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram.class);
                    intent.putExtra("variable4B", true);
                    startActivity(intent);
                } else if (checkWorkout2 == "hypertrophyA"){
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram.class);
                    intent.putExtra("variable4A", true);
                    startActivity(intent);
                }
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkWorkout == "strengthB") {
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram2.class);
                    intent.putExtra("variable5_5B", true);
                    startActivity(intent);
                } else if (checkWorkout == "strengthA") {
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram2.class);
                    intent.putExtra("variable5_5A", true);
                    startActivity(intent);
                } else if (checkWorkout2 == "hypertrophyB"){
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram.class);
                    intent.putExtra("variable5B", true);
                    startActivity(intent);
                } else if (checkWorkout2 == "hypertrophyA"){
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram.class);
                    intent.putExtra("variable5A", true);
                    startActivity(intent);
                }
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkWorkout == "strengthB") {
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram2.class);
                    intent.putExtra("variable6_6B", true);
                    startActivity(intent);
                } else if (checkWorkout == "strengthA") {
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram2.class);
                    intent.putExtra("variable6_6A", true);
                    startActivity(intent);
                } else if (checkWorkout2 == "hypertrophyB"){
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram.class);
                    intent.putExtra("variable6B", true);
                    startActivity(intent);
                } else if (checkWorkout2 == "hypertrophyA"){
                    Intent intent = new Intent(GeneratedProgramWorkouts.this, GeneratedProgram.class);
                    intent.putExtra("variable6A", true);
                    startActivity(intent);
                }
            }
        });

    }
}