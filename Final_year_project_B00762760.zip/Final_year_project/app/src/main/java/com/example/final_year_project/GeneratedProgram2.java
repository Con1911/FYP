package com.example.final_year_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import java.util.List;

public class GeneratedProgram2 extends AppCompatActivity {

    Button button, button2, buttonHome;
    TextView wkt1, wkt2, wkt3, set1, set2, set3, rep1, rep2, rep3, timerTmp;
    TextView workoutName, exercise1, exercise2, exercise3, weights1, weights2, weights3, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12;
    String wName, ex1, ex2, ex3, wt1, wt2, wt3, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12;
    public int counter = 0;
    public int counter2 = 0;
    public CountDownTimer myCountDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generated_program2);


        button = findViewById(R.id.startTimerBtn2);
        button2 = findViewById(R.id.saveWKTbtn2);
        timerTmp = findViewById(R.id.timer2);
        String userName = ParseUser.getCurrentUser().getUsername();
        boolean var1B = this.getIntent().getExtras().getBoolean("variable1_1B");
        boolean var2B = this.getIntent().getExtras().getBoolean("variable2_2B");
        boolean var3B = this.getIntent().getExtras().getBoolean("variable3_3B");
        boolean var4B = this.getIntent().getExtras().getBoolean("variable4_4B");
        boolean var5B = this.getIntent().getExtras().getBoolean("variable5_5B");
        boolean var6B = this.getIntent().getExtras().getBoolean("variable6_6B");

        boolean var1A = this.getIntent().getExtras().getBoolean("variable1_1A");
        boolean var2A = this.getIntent().getExtras().getBoolean("variable2_2A");
        boolean var3A = this.getIntent().getExtras().getBoolean("variable3_3A");
        boolean var4A = this.getIntent().getExtras().getBoolean("variable4_4A");
        boolean var5A = this.getIntent().getExtras().getBoolean("variable5_5A");
        boolean var6A = this.getIntent().getExtras().getBoolean("variable6_6A");

        if (var1B){
            GetStrength1B();
        } else if (var1A){
            GetStrength1A();
        } else if (var2B){
            GetStrength2B();
        } else if (var2A){
            GetStrength2A();
        } else if (var3B){
            GetStrength3B();
        } else if (var3A){
            GetStrength3A();
        } else if (var4B){
            GetStrength4B();
        } else if (var4A){
            GetStrength4A();
        } else if (var5B){
            GetStrength5B();
        } else if (var5A){
            GetStrength5A();
        } else if (var6B){
            GetStrength6B();
        } else if (var6A){
            GetStrength6A();
        }


        buttonHome = (Button)findViewById(R.id.buttonHome);
        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (GeneratedProgram2.this, HomeActivity.class);
                startActivity(intent);
            }
        });





        //Timer
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myCountDownTimer = new CountDownTimer(300000, 1000) {
                    public void onTick(long millisUntilFinished) {
                        if (counter2 != 5) {
                            timerTmp.setText(String.valueOf("00:0" + counter));
                            if (counter >= 10) {
                                timerTmp.setText(String.valueOf("00:" + counter));
                            }
                            if (counter >= 60) {
                                counter = 0;
                                counter2++;
                            }
                            if (counter2 == 1){
                                timerTmp.setText(String.valueOf("01:0" + counter));
                                if (counter >= 10) {
                                    timerTmp.setText(String.valueOf("01:" + counter));
                                }
                            }

                            if (counter2 == 2){
                                timerTmp.setText(String.valueOf("02:0" + counter));
                                if (counter >= 10) {
                                    timerTmp.setText(String.valueOf("02:" + counter));
                                }
                            }

                            if (counter2 == 3){
                                timerTmp.setText(String.valueOf("03:0" + counter));
                                if (counter >= 10) {
                                    timerTmp.setText(String.valueOf("03:" + counter));
                                }
                            }

                            if (counter2 == 4){
                                timerTmp.setText(String.valueOf("04:0" + counter));
                                if (counter >= 10) {
                                    timerTmp.setText(String.valueOf("04:" + counter));
                                }
                                if (counter == 50){
                                    playSound();
                                }
                            }
                            counter++;
                        }
                    }

                    public void onFinish() {
                        timerTmp.setText("REST FINISHED");
                        button.setText("Restart Timer");
                    }
                }.start();
                counter = 0;
                counter2 = 0;
            }
        });


        //save workout
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                exercise1 = findViewById(R.id.exerciseExple1ex1);
                exercise2 = findViewById(R.id.exerciseExple2ex1);
                exercise3 = findViewById(R.id.exerciseExple3ex1);

                ex1 = exercise1.getText().toString();
                ex2 = exercise2.getText().toString();
                ex3 = exercise3.getText().toString();

                workoutName = findViewById(R.id.Exercise_titleex1);
                weights1 = findViewById(R.id.weight1ex1);
                weights2 = findViewById(R.id.weight2ex1);
                weights3 = findViewById(R.id.weight3ex1);

                wName = workoutName.getText().toString();

                wt1 = weights1.getText().toString();
                wt2 = weights2.getText().toString();
                wt3 = weights3.getText().toString();

                s1 = findViewById(R.id.rp1_1ex1);
                s2 = findViewById(R.id.rp2_1ex1);
                s3 = findViewById(R.id.rp3_1ex1);
                s4 = findViewById(R.id.rp4_1ex1);
                r1 = s1.getText().toString();
                r2 = s2.getText().toString();
                r3 = s3.getText().toString();
                r4 = s4.getText().toString();

                s5 = findViewById(R.id.rp1_2ex1);
                s6 = findViewById(R.id.rp2_2ex1);
                s7 = findViewById(R.id.rp3_2ex1);
                s8 = findViewById(R.id.rp4_2ex1);
                r5 = s5.getText().toString();
                r6 = s6.getText().toString();
                r7 = s7.getText().toString();
                r8 = s8.getText().toString();

                s9 = findViewById(R.id.rp1_3ex1);
                s10 = findViewById(R.id.rp2_3ex1);
                s11 = findViewById(R.id.rp3_3ex1);
                s12 = findViewById(R.id.rp4_3ex1);
                r9 = s9.getText().toString();
                r10 = s10.getText().toString();
                r11 = s11.getText().toString();
                r12 = s12.getText().toString();



                AddData(userName, wName, ex1, ex2, ex3, wt1, wt2, wt3, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12);
            }
        });

    }


    //play sound method
    public void playSound() {
        MediaPlayer mp = MediaPlayer.create(GeneratedProgram2.this, (R.raw.music));
        mp.start();
    }


    //add workout data
    public void AddData(String userName, String workoutName, String exercise1, String exercise2, String exercise3, String weights1, String weights2, String weights3, String s1, String s2, String s3, String s4, String s5, String s6, String s7, String s8, String s9, String s10, String s11, String s12){

        ParseObject AddExercise = new ParseObject("exercises2");

        AddExercise.put("username", userName);
        AddExercise.put("workoutName", workoutName);

        AddExercise.put("exercise1", exercise1);
        AddExercise.put("exercise2", exercise2);
        AddExercise.put("exercise3", exercise3);

        AddExercise.put("weight1", weights1);
        AddExercise.put("weight2", weights2);
        AddExercise.put("weight3", weights3);

        AddExercise.put("set1", s1);
        AddExercise.put("set2", s2);
        AddExercise.put("set3", s3);
        AddExercise.put("set4", s4);
        AddExercise.put("set5", s5);
        AddExercise.put("set6", s6);
        AddExercise.put("set7", s7);
        AddExercise.put("set8", s8);
        AddExercise.put("set9", s9);
        AddExercise.put("set10", s10);
        AddExercise.put("set11", s11);
        AddExercise.put("set12", s12);

        AddExercise.saveInBackground(new SaveCallback() {
            @Override
            public void done(ParseException e) {

                if (e == null) {
                    Toast.makeText(GeneratedProgram2.this, "Workout saved!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), e.getMessage().toString(), Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    public void GetStrength1B(){
        wkt1 = findViewById(R.id.exerciseExple1ex1);
        wkt2 = findViewById(R.id.exerciseExple2ex1);
        wkt3 = findViewById(R.id.exerciseExple3ex1);
        set1 = findViewById(R.id.sets1ex1);
        set2 = findViewById(R.id.sets2ex1);
        set3 = findViewById(R.id.sets3ex1);
        rep1 = findViewById(R.id.reps1ex1);
        rep2 = findViewById(R.id.reps2ex1);
        rep3 = findViewById(R.id.reps3ex1);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "AVdwKDJmhU");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise3");
                        String workout3 = objects.get(i).getString("exercise2");
                        String sets1 = objects.get(i).getString("sets2");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("strengthReps1");
                        String reps2 = objects.get(i).getString("strengthReps1");
                        String reps3 = objects.get(i).getString("strengthReps2");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram2.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    public void GetStrength1A(){
        wkt1 = findViewById(R.id.exerciseExple1ex1);
        wkt2 = findViewById(R.id.exerciseExple2ex1);
        wkt3 = findViewById(R.id.exerciseExple3ex1);
        set1 = findViewById(R.id.sets1ex1);
        set2 = findViewById(R.id.sets2ex1);
        set3 = findViewById(R.id.sets3ex1);
        rep1 = findViewById(R.id.reps1ex1);
        rep2 = findViewById(R.id.reps2ex1);
        rep3 = findViewById(R.id.reps3ex1);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "AVdwKDJmhU");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise3");
                        String workout3 = objects.get(i).getString("exercise2");
                        String sets1 = objects.get(i).getString("strengthSets2");
                        String sets2 = objects.get(i).getString("strengthSets2");
                        String sets3 = objects.get(i).getString("strengthSets2");
                        String reps1 = objects.get(i).getString("strengthReps1");
                        String reps2 = objects.get(i).getString("strengthReps1");
                        String reps3 = objects.get(i).getString("strengthReps2");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram2.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    public void GetStrength2B(){
        wkt1 = findViewById(R.id.exerciseExple1ex1);
        wkt2 = findViewById(R.id.exerciseExple2ex1);
        wkt3 = findViewById(R.id.exerciseExple3ex1);
        set1 = findViewById(R.id.sets1ex1);
        set2 = findViewById(R.id.sets2ex1);
        set3 = findViewById(R.id.sets3ex1);
        rep1 = findViewById(R.id.reps1ex1);
        rep2 = findViewById(R.id.reps2ex1);
        rep3 = findViewById(R.id.reps3ex1);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "Govub5N6iZ");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise3");
                        String workout3 = objects.get(i).getString("exercise2");
                        String sets1 = objects.get(i).getString("sets2");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("strengthReps1");
                        String reps2 = objects.get(i).getString("strengthReps1");
                        String reps3 = objects.get(i).getString("strengthReps2");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram2.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    public void GetStrength2A(){
        wkt1 = findViewById(R.id.exerciseExple1ex1);
        wkt2 = findViewById(R.id.exerciseExple2ex1);
        wkt3 = findViewById(R.id.exerciseExple3ex1);
        set1 = findViewById(R.id.sets1ex1);
        set2 = findViewById(R.id.sets2ex1);
        set3 = findViewById(R.id.sets3ex1);
        rep1 = findViewById(R.id.reps1ex1);
        rep2 = findViewById(R.id.reps2ex1);
        rep3 = findViewById(R.id.reps3ex1);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "Govub5N6iZ");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise3");
                        String workout3 = objects.get(i).getString("exercise2");
                        String sets1 = objects.get(i).getString("strengthSets2");
                        String sets2 = objects.get(i).getString("strengthSets2");
                        String sets3 = objects.get(i).getString("strengthSets2");
                        String reps1 = objects.get(i).getString("strengthReps1");
                        String reps2 = objects.get(i).getString("strengthReps1");
                        String reps3 = objects.get(i).getString("strengthReps2");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram2.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    public void GetStrength3B(){
        wkt1 = findViewById(R.id.exerciseExple1ex1);
        wkt2 = findViewById(R.id.exerciseExple2ex1);
        wkt3 = findViewById(R.id.exerciseExple3ex1);
        set1 = findViewById(R.id.sets1ex1);
        set2 = findViewById(R.id.sets2ex1);
        set3 = findViewById(R.id.sets3ex1);
        rep1 = findViewById(R.id.reps1ex1);
        rep2 = findViewById(R.id.reps2ex1);
        rep3 = findViewById(R.id.reps3ex1);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "Yv3B2f8C9Y");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise3");
                        String workout3 = objects.get(i).getString("exercise2");
                        String sets1 = objects.get(i).getString("sets2");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("strengthReps1");
                        String reps2 = objects.get(i).getString("strengthReps1");
                        String reps3 = objects.get(i).getString("strengthReps2");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram2.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    public void GetStrength3A(){
        wkt1 = findViewById(R.id.exerciseExple1ex1);
        wkt2 = findViewById(R.id.exerciseExple2ex1);
        wkt3 = findViewById(R.id.exerciseExple3ex1);
        set1 = findViewById(R.id.sets1ex1);
        set2 = findViewById(R.id.sets2ex1);
        set3 = findViewById(R.id.sets3ex1);
        rep1 = findViewById(R.id.reps1ex1);
        rep2 = findViewById(R.id.reps2ex1);
        rep3 = findViewById(R.id.reps3ex1);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "Yv3B2f8C9Y");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise3");
                        String workout3 = objects.get(i).getString("exercise2");
                        String sets1 = objects.get(i).getString("strengthSets2");
                        String sets2 = objects.get(i).getString("strengthSets2");
                        String sets3 = objects.get(i).getString("strengthSets2");
                        String reps1 = objects.get(i).getString("strengthReps1");
                        String reps2 = objects.get(i).getString("strengthReps1");
                        String reps3 = objects.get(i).getString("strengthReps2");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram2.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    public void GetStrength4B(){
        wkt1 = findViewById(R.id.exerciseExple1ex1);
        wkt2 = findViewById(R.id.exerciseExple2ex1);
        wkt3 = findViewById(R.id.exerciseExple3ex1);
        set1 = findViewById(R.id.sets1ex1);
        set2 = findViewById(R.id.sets2ex1);
        set3 = findViewById(R.id.sets3ex1);
        rep1 = findViewById(R.id.reps1ex1);
        rep2 = findViewById(R.id.reps2ex1);
        rep3 = findViewById(R.id.reps3ex1);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "mXTkWCdvh5");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise3");
                        String workout3 = objects.get(i).getString("exercise2");
                        String sets1 = objects.get(i).getString("sets2");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("strengthReps1");
                        String reps2 = objects.get(i).getString("strengthReps1");
                        String reps3 = objects.get(i).getString("strengthReps2");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram2.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    public void GetStrength4A(){
        wkt1 = findViewById(R.id.exerciseExple1ex1);
        wkt2 = findViewById(R.id.exerciseExple2ex1);
        wkt3 = findViewById(R.id.exerciseExple3ex1);
        set1 = findViewById(R.id.sets1ex1);
        set2 = findViewById(R.id.sets2ex1);
        set3 = findViewById(R.id.sets3ex1);
        rep1 = findViewById(R.id.reps1ex1);
        rep2 = findViewById(R.id.reps2ex1);
        rep3 = findViewById(R.id.reps3ex1);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "mXTkWCdvh5");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise3");
                        String workout3 = objects.get(i).getString("exercise2");
                        String sets1 = objects.get(i).getString("strengthSets2");
                        String sets2 = objects.get(i).getString("strengthSets2");
                        String sets3 = objects.get(i).getString("strengthSets2");
                        String reps1 = objects.get(i).getString("strengthReps1");
                        String reps2 = objects.get(i).getString("strengthReps1");
                        String reps3 = objects.get(i).getString("strengthReps2");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram2.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    public void GetStrength5B(){
        wkt1 = findViewById(R.id.exerciseExple1ex1);
        wkt2 = findViewById(R.id.exerciseExple2ex1);
        wkt3 = findViewById(R.id.exerciseExple3ex1);
        set1 = findViewById(R.id.sets1ex1);
        set2 = findViewById(R.id.sets2ex1);
        set3 = findViewById(R.id.sets3ex1);
        rep1 = findViewById(R.id.reps1ex1);
        rep2 = findViewById(R.id.reps2ex1);
        rep3 = findViewById(R.id.reps3ex1);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "AnR9rEmDGL");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise3");
                        String workout3 = objects.get(i).getString("exercise2");
                        String sets1 = objects.get(i).getString("sets2");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("strengthReps1");
                        String reps2 = objects.get(i).getString("strengthReps1");
                        String reps3 = objects.get(i).getString("strengthReps2");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram2.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    public void GetStrength5A(){
        wkt1 = findViewById(R.id.exerciseExple1ex1);
        wkt2 = findViewById(R.id.exerciseExple2ex1);
        wkt3 = findViewById(R.id.exerciseExple3ex1);
        set1 = findViewById(R.id.sets1ex1);
        set2 = findViewById(R.id.sets2ex1);
        set3 = findViewById(R.id.sets3ex1);
        rep1 = findViewById(R.id.reps1ex1);
        rep2 = findViewById(R.id.reps2ex1);
        rep3 = findViewById(R.id.reps3ex1);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "AnR9rEmDGL");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise3");
                        String workout3 = objects.get(i).getString("exercise2");
                        String sets1 = objects.get(i).getString("strengthSets2");
                        String sets2 = objects.get(i).getString("strengthSets2");
                        String sets3 = objects.get(i).getString("strengthSets2");
                        String reps1 = objects.get(i).getString("strengthReps1");
                        String reps2 = objects.get(i).getString("strengthReps1");
                        String reps3 = objects.get(i).getString("strengthReps2");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram2.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    public void GetStrength6B(){
        wkt1 = findViewById(R.id.exerciseExple1ex1);
        wkt2 = findViewById(R.id.exerciseExple2ex1);
        wkt3 = findViewById(R.id.exerciseExple3ex1);
        set1 = findViewById(R.id.sets1ex1);
        set2 = findViewById(R.id.sets2ex1);
        set3 = findViewById(R.id.sets3ex1);
        rep1 = findViewById(R.id.reps1ex1);
        rep2 = findViewById(R.id.reps2ex1);
        rep3 = findViewById(R.id.reps3ex1);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "DebnWpObdk");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise3");
                        String workout3 = objects.get(i).getString("exercise2");
                        String sets1 = objects.get(i).getString("sets2");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("strengthReps1");
                        String reps2 = objects.get(i).getString("strengthReps1");
                        String reps3 = objects.get(i).getString("strengthReps2");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram2.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


    public void GetStrength6A(){
        wkt1 = findViewById(R.id.exerciseExple1ex1);
        wkt2 = findViewById(R.id.exerciseExple2ex1);
        wkt3 = findViewById(R.id.exerciseExple3ex1);
        set1 = findViewById(R.id.sets1ex1);
        set2 = findViewById(R.id.sets2ex1);
        set3 = findViewById(R.id.sets3ex1);
        rep1 = findViewById(R.id.reps1ex1);
        rep2 = findViewById(R.id.reps2ex1);
        rep3 = findViewById(R.id.reps3ex1);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "DebnWpObdk");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise3");
                        String workout3 = objects.get(i).getString("exercise2");
                        String sets1 = objects.get(i).getString("strengthSets2");
                        String sets2 = objects.get(i).getString("strengthSets2");
                        String sets3 = objects.get(i).getString("strengthSets2");
                        String reps1 = objects.get(i).getString("strengthReps1");
                        String reps2 = objects.get(i).getString("strengthReps1");
                        String reps3 = objects.get(i).getString("strengthReps2");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram2.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }




    }
