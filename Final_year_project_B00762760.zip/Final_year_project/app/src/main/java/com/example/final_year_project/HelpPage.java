package com.example.final_year_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class HelpPage extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_page);

        Spinner spinner = findViewById(R.id.spinnerExercises);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.exerciseTypes, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        ImageView v1 = (ImageView)findViewById(R.id.imageViewExercises);


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch(position){
            case 0:
                     ImageView v2 = findViewById(R.id.imageViewExercises);
                     v2.setImageResource(R.drawable.bench);
                     TextView t2 = findViewById(R.id.textViewSelect);
                     String s2 = "Start start with the bar over your shoulders before bringing it down to your chest and pressing back up";
                     t2.setText(s2);
                break;
            case 1:
                ImageView v3 = findViewById(R.id.imageViewExercises);
                v3.setImageResource(R.drawable.shoulderpress);
                TextView t3 = findViewById(R.id.textViewSelect);
                String s3 = "Start with the bar at shoulder level before presing the bar overhead";
                t3.setText(s3);
                break;
            case 2:
                ImageView v4 = findViewById(R.id.imageViewExercises);
                v4.setImageResource(R.drawable.inclinepress);
                TextView t4 = findViewById(R.id.textViewSelect);
                String s4 = "With the bench at an incline bring the bar down to your chest before pressing back up";
                t4.setText(s4);
                break;
            case 3:
                ImageView v5 = findViewById(R.id.imageViewExercises);
                v5.setImageResource(R.drawable.lateralraise);
                TextView t5 = findViewById(R.id.textViewSelect);
                String s5 = "Start with the dumbells by your side before raising your arms out to the side";
                t5.setText(s5);
                break;
            case 4:
                ImageView v6 = findViewById(R.id.imageViewExercises);
                v6.setImageResource(R.drawable.bicepcurl);
                TextView t6 = findViewById(R.id.textViewSelect);
                String s6 = "With your arms at your side flex your elbow and bring the weight up to your chest";
                t6.setText(s6);
                break;
            case 5:
                ImageView v7 = findViewById(R.id.imageViewExercises);
                v7.setImageResource(R.drawable.barbellrow);
                TextView t7 = findViewById(R.id.textViewSelect);
                String s7 = "With the barbell infront of your shins, bendover and pull the bar up to your chest";
                t7.setText(s7);
                break;
            case 6:
                ImageView v8 = findViewById(R.id.imageViewExercises);
                v8.setImageResource(R.drawable.latpulldown);
                TextView t8 = findViewById(R.id.textViewSelect);
                String s8 = "Grap the bar and pull your elbows down and tucked in";
                t8.setText(s8);
                break;
            case 7:
                ImageView v9 = findViewById(R.id.imageViewExercises);
                v9.setImageResource(R.drawable.hammercurl);
                TextView t9 = findViewById(R.id.textViewSelect);
                String s9 = "With your wrists in a neutral grip curl the weight up towards your chest";
                t9.setText(s9);
                break;
            case 8:
                ImageView v10 = findViewById(R.id.imageViewExercises);
                v10.setImageResource(R.drawable.reardeltfly);
                TextView t10 = findViewById(R.id.textViewSelect);
                String s10 = "Bend over and raise the dumbells out to the side and back down";
                t10.setText(s10);
                break;
            case 9:
                ImageView v11 = findViewById(R.id.imageViewExercises);
                v11.setImageResource(R.drawable.barbellcurl);
                TextView t11 = findViewById(R.id.textViewSelect);
                String s11 = "With the barbell infront of your body, curl the weight up towards your chest";
                t11.setText(s11);
                break;
            case 10:
                ImageView v12 = findViewById(R.id.imageViewExercises);
                v12.setImageResource(R.drawable.deadlift);
                TextView t12 = findViewById(R.id.textViewSelect);
                String s12 = "With the bar an inch away from your shins, grab the bar and with a straight back, pull up the weight";
                t12.setText(s12);
                break;
            case 11:
                ImageView v13 = findViewById(R.id.imageViewExercises);
                v13.setImageResource(R.drawable.squat);
                TextView t13 = findViewById(R.id.textViewSelect);
                String s13 = "With the bar resting on the back of your shoulders, squat down as far as possible with good form";
                t13.setText(s13);
                break;
            case 12:
                ImageView v14 = findViewById(R.id.imageViewExercises);
                v14.setImageResource(R.drawable.legpress);
                TextView t14 = findViewById(R.id.textViewSelect);
                String s14 = "Lower the weight slowly down before pressing back up";
                t14.setText(s14);
                break;
            case 13:
                ImageView v15 = findViewById(R.id.imageViewExercises);
                v15.setImageResource(R.drawable.hamstringcurl);
                TextView t15 = findViewById(R.id.textViewSelect);
                String s15 = "With the weight resting on your ankles, curl the weight up and slowly back down";
                t15.setText(s15);
                break;
            case 14:
                ImageView v16 = findViewById(R.id.imageViewExercises);
                v16.setImageResource(R.drawable.legextension);
                TextView t16 = findViewById(R.id.textViewSelect);
                String s16 = "With the weight resting on your shins, extend your legs up and slowly back down";
                t16.setText(s16);
                break;
            case 15:
                ImageView v17 = findViewById(R.id.imageViewExercises);
                v17.setImageResource(R.drawable.dumbellpress);
                TextView t17 = findViewById(R.id.textViewSelect);
                String s17 = "Laying flat on the bench, bring the dumbells slowly down to your chest and press back up";
                t17.setText(s17);
                break;
            case 16:
                ImageView v18 = findViewById(R.id.imageViewExercises);
                v18.setImageResource(R.drawable.cableflys);
                TextView t18 = findViewById(R.id.textViewSelect);
                String s18 = "Start with your hand out wide and with a straight arm bring them together";
                t18.setText(s18);
                break;
            case 17:
                ImageView v19 = findViewById(R.id.imageViewExercises);
                v19.setImageResource(R.drawable.tricepext);
                TextView t19 = findViewById(R.id.textViewSelect);
                String s19 = "With your arms over your head, bring the weight down slow and extend your elbow";
                t19.setText(s19);
                break;
            case 18:
                ImageView v20 = findViewById(R.id.imageViewExercises);
                v20.setImageResource(R.drawable.cablecurl);
                TextView t20 = findViewById(R.id.textViewSelect);
                String s20 = "With the bar infront of your body curl the weight up towards your chest";
                t20.setText(s20);
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}