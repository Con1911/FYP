package com.example.final_year_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.ParseUser;

public class SignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        EditText usernameText = (EditText) findViewById(R.id.editText_ca_uname);
        EditText passwordText = (EditText) findViewById(R.id.editText_ca_password);
        EditText confirmPasswordText = (EditText) findViewById(R.id.editText_ca_cpassword);
        Button regButton = (Button) findViewById(R.id.button_ca);

        regButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = usernameText.getText().toString();
                String password = passwordText.getText().toString();
                String conf_password = confirmPasswordText.getText().toString();

                if (TextUtils.isEmpty(username)) {
                    usernameText.setError("Please enter your user name");
                }
                if (TextUtils.isEmpty(password)) {
                    passwordText.setError("Please enter your password");
                }
                if (TextUtils.isEmpty(conf_password)) {
                    confirmPasswordText.setError("Please confirm your password");
                }else if(password.equals(conf_password) )
                    signUp(username, password);
                else
                    Toast.makeText(SignUpActivity.this, "Make sure that the passwords entered match.", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void signUp(String uname, String pword){
        ParseUser user = new ParseUser();

        user.setUsername(uname);
        user.setPassword(pword);
        user.signUpInBackground(e -> {
            if(e == null){
                Toast.makeText(SignUpActivity.this, "User Registered successfully", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(SignUpActivity.this, MainActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(SignUpActivity.this ,"User already exists", Toast.LENGTH_LONG).show();
            }
        });
    }
}
