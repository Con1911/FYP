package com.example.final_year_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class EnterInfo extends AppCompatActivity {

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_info);

        Spinner trainingExp = findViewById(R.id.spinner_trainingExperience);
        String[] items = new String[]{"Less than 1 year", "1 year", "2 years", "3+ years"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        trainingExp.setAdapter(adapter);

        Spinner trainingGoals = findViewById(R.id.spinner_trainingGoals);
        String[] items2 = new String[]{"Pure strength", "Pure Hypertrophy", "Strength and Hypertrophy"};
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items2);
        trainingGoals.setAdapter(adapter2);

        Spinner trainingDays = findViewById(R.id.spinner_trainingDays);
        String[] items3 = new String[]{"3 days", "4 days", "4+ days"};
        ArrayAdapter<String> adapter3 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items3);
        trainingDays.setAdapter(adapter3);

        button = (Button) findViewById(R.id.button_generateProgram);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EnterInfo.this, GeneratedProgram.class);
                startActivity(intent);
            }
        });
    }
}