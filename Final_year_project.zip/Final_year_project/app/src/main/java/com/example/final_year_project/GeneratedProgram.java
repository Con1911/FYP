package com.example.final_year_project;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.List;

public class GeneratedProgram extends AppCompatActivity {


    Button button;
    TextView wkt1, wkt2, wkt3, wkt4, wkt5, set1, set2, set3, set4, set5, rep1, rep2, rep3, rep4, rep5, timerTmp;
    public int counter = 0;
    public int counter2 = 0;
    public CountDownTimer myCountDownTimer;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generated_program);

        button = findViewById(R.id.startTimerBtn);
        timerTmp = findViewById(R.id.timer);

        wkt1 = findViewById(R.id.exerciseExple1);
        wkt2 = findViewById(R.id.exerciseExple2);
        wkt3 = findViewById(R.id.exerciseExple3);
        wkt4 = findViewById(R.id.exerciseExple4);
        wkt5 = findViewById(R.id.exerciseExple5);
        set1 = findViewById(R.id.sets1);
        set2 = findViewById(R.id.sets2);
        set3 = findViewById(R.id.sets3);
        set4 = findViewById(R.id.sets4);
        set5 = findViewById(R.id.sets5);
        rep1 = findViewById(R.id.reps1);
        rep2 = findViewById(R.id.reps2);
        rep3 = findViewById(R.id.reps3);
        rep4 = findViewById(R.id.reps4);
        rep5 = findViewById(R.id.reps5);

        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises");
        query.whereEqualTo("objectId", "AVdwKDJmhU");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                for (int i = 0; i < objects.size(); i++) {
                    if (e == null) {

                        String workout1 = objects.get(i).getString("exercise");
                        String workout2 = objects.get(i).getString("exercise2");
                        String workout3 = objects.get(i).getString("exercise3");
                        String workout4 = objects.get(i).getString("exercise4");
                        String workout5 = objects.get(i).getString("exercise5");
                        String sets1 = objects.get(i).getString("sets1");
                        String sets2 = objects.get(i).getString("sets2");
                        String sets3 = objects.get(i).getString("sets2");
                        String sets4 = objects.get(i).getString("sets1");
                        String sets5 = objects.get(i).getString("sets2");
                        String reps1 = objects.get(i).getString("repRange3");
                        String reps2 = objects.get(i).getString("repRange2");
                        String reps3 = objects.get(i).getString("repRange2");
                        String reps4 = objects.get(i).getString("repRange1");
                        String reps5 = objects.get(i).getString("repRange3");

                        wkt1.setText(workout1);
                        wkt2.setText(workout2);
                        wkt3.setText(workout3);
                        wkt4.setText(workout4);
                        wkt5.setText(workout5);
                        set1.setText(sets1);
                        set2.setText(sets2);
                        set3.setText(sets3);
                        set4.setText(sets4);
                        set5.setText(sets5);
                        rep1.setText(reps1);
                        rep2.setText(reps2);
                        rep3.setText(reps3);
                        rep4.setText(reps4);
                        rep5.setText(reps5);
                    } else {
                        // handling error if we get any error.
                        Toast.makeText(GeneratedProgram.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myCountDownTimer = new CountDownTimer(120000, 1000) {
                    public void onTick(long millisUntilFinished) {
                        if (counter2 != 2) {
                            timerTmp.setText(String.valueOf("00:0" + counter));
                            if (counter >= 10) {
                                timerTmp.setText(String.valueOf("00:" + counter));
                            }
                            if (counter >= 60) {
                                counter = 0;
                                counter2++;
                            }
                            if (counter2 == 1){
                                timerTmp.setText(String.valueOf("01:0" + counter));
                                if (counter >= 10) {
                                    timerTmp.setText(String.valueOf("01:" + counter));
                                }
                                if (counter == 50){
                                    playSound();
                                }
                            }
                            counter++;
                        }
                    }

                    public void onFinish() {
                        timerTmp.setText("REST FINISH!!");
                        button.setText("Restart Timer");

                    }
                }.start();
                counter = 0;

            }
        });

    }

    public void playSound() {
        MediaPlayer mp = MediaPlayer.create(GeneratedProgram.this, (R.raw.music));
        mp.start();

    }
}