package com.example.final_year_project;

public class WorkoutModal {

    private String workoutName, exercise, exercise2, exercise3, exercise4, exercise5, DBwt1, DBwt2, DBwt3, DBwt4, DBwt5, DBs1r1, DBs1r2, DBs1r3, DBs1r4, DBs2r1, DBs2r2, DBs2r3, DBs2r4, DBs3r1, DBs3r2,DBs3r3, DBs3r4, DBs4r1, DBs4r2,DBs4r3, DBs4r4, DBs5r1, DBs5r2,DBs5r3, DBs5r4 ;


    public WorkoutModal(String workoutName, String exercise){
        this.workoutName = workoutName;
        this.exercise = exercise;
    }

    public String getWorkoutName(){
        return workoutName;
    }

    public void setWorkoutName(){
        this.workoutName = workoutName;
    }

    public String getExercise(){
        return exercise;
    }

    public void setExercise(){
        this.exercise = exercise;
    }

    public String getExercise2(){
        return exercise2;
    }

    public void setExercise2(){
        this.exercise2 = exercise2;
    }
    public String getExercise3(){
        return exercise3;
    }

    public void setExercise3(){
        this.exercise3 = exercise3;
    }
    public String getExercise4(){
        return exercise4;
    }

    public void setExercise4(){
        this.exercise4 = exercise4;
    }
    public String getExercise5(){
        return exercise5;
    }

    public void setExercise5(){
        this.exercise5 = exercise5;
    }
    public String getDBwt1(){
        return DBwt1;
    }

    public void setDBwt1(){
        this.DBwt1 = DBwt1;
    }
    public String getDBwt2(){
        return DBwt2;
    }

    public void setDBwt2(){
        this.DBwt2 = DBwt2;
    }
    public String getDBwt3(){
        return DBwt3;
    }

    public void setDBwt3(){
        this.DBwt3 = DBwt3;
    }
    public String getDBwt4(){
        return DBwt4;
    }

    public void setDBwt4(){
        this.DBwt4 = DBwt4;
    }
    public String getDBwt5(){
        return DBwt5;
    }

    public void setDBwt5(){
        this.DBwt5 = DBwt5;
    }
    public String getDBs1r1(){
        return DBs1r1;
    }

    public void setDBs1r1(){
        this.DBs1r1 = DBs1r1;
    }
    public String getDBs1r2(){
        return DBs1r2;
    }

    public void setDBs1r2(){
        this.DBs1r2 = DBs1r2;
    }
    public String getDBs1r3(){
        return DBs1r3;
    }

    public void setDBs1r3(){
        this.DBs1r3 = DBs1r3;
    }

    public String getDBs1r4(){
        return DBs1r4;
    }

    public void setDBs1r4(){
        this.DBs1r4 = DBs1r4;
    }

    public String getDBs2r1(){
        return DBs2r1;
    }

    public void setDBs2r1(){
        this.DBs2r1 = DBs2r1;
    }
    public String getDBs2r2(){
        return DBs2r2;
    }

    public void setDBs2r2(){
        this.DBs2r2 = DBs2r2;
    }
    public String getDBs2r3(){
        return DBs2r3;
    }

    public void setDBs2r3(){
        this.DBs2r3 = DBs2r3;
    }
    public String getDBs2r4(){
        return DBs2r4;
    }

    public void setDBs2r4(){
        this.DBs2r4 = DBs2r4;
    }

    public String getDBs3r1(){
        return DBs3r1;
    }

    public void setDBs3r1(){
        this.DBs3r1 = DBs3r1;
    }

    public String getDBs3r2(){
        return DBs3r2;
    }

    public void setDBs3r2(){
        this.DBs3r2 = DBs3r2;
    }
    public String getDBs3r3(){
        return DBs3r3;
    }

    public void setDBs3r3(){
        this.DBs3r3 = DBs3r3;
    }
    public String getDBs3r4(){
        return DBs3r4;
    }

    public void setDBs3r4(){
        this.DBs3r4 = DBs3r4;
    }
    public String getDBs4r1(){
        return DBs4r1;
    }

    public void setDBs4r1(){
        this.DBs4r1 = DBs4r1;
    }
    public String getDBs4r2(){
        return DBs4r2;
    }

    public void setDBs4r2(){
        this.DBs4r2 = DBs4r2;
    }
    public String getDBs4r3(){
        return DBs4r3;
    }

    public void setDBs4r3(){
        this.DBs4r3 = DBs4r3;
    }
    public String getDBs4r4(){
        return DBs4r4;
    }

    public void setDBs4r4(){
        this.DBs4r4 = DBs4r4;
    }

    public String getDBs5r1(){
        return DBs5r1;
    }

    public void setDBs5r1(){
        this.DBs5r1 = DBs5r1;
    }
    public String getDBs5r2(){
        return DBs5r2;
    }

    public void setDBs5r2(){
        this.DBs5r2 = DBs5r2;
    }
    public String getDBs5r3(){
        return DBs5r3;
    }

    public void setDBs5r3(){
        this.DBs5r3 = DBs5r3;
    }
    public String getDBs5r4(){
        return DBs5r4;
    }

    public void setDBs5r4(){
        this.DBs5r4 = DBs5r4;
    }
}
