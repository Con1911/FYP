package com.example.final_year_project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.parse.ParseObject;

import java.util.ArrayList;
import java.util.List;

public class workoutRVadapter extends RecyclerView.Adapter<workoutRVadapter.ViewHolder> {
TextView test;
    private Context context;
    private ArrayList<WorkoutModal> workoutModalArrayList;


    public workoutRVadapter(Context context, ArrayList<WorkoutModal> workoutModalArrayList){
        this.context = context;
        this.workoutModalArrayList = workoutModalArrayList;
    }

    @NonNull
    @Override
    public workoutRVadapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.workout_rv_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull workoutRVadapter.ViewHolder holder, int position) {

        WorkoutModal workouts = workoutModalArrayList.get(position);
        holder.workoutNameTV.setText(workouts.getWorkoutName());
        holder.exerciseTV.setText(workouts.getExercise());

    }



    @Override
    public int getItemCount() {
        return workoutModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private final TextView workoutNameTV;
        private final TextView exerciseTV;

        public ViewHolder(@NonNull View itemView){
            super(itemView);
            workoutNameTV = itemView.findViewById(R.id.idTVworkoutName);
            exerciseTV = itemView.findViewById(R.id.textViewEx1);

        }
    }
}
