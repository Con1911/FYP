package com.example.final_year_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.util.ArrayList;
import java.util.List;

public class MyWorkouts extends AppCompatActivity {

    private RecyclerView workoutsRV;
    private ArrayList<WorkoutModal> workoutModalArrayList;
    private workoutRVadapter WorkoutRVadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_workouts);

        workoutsRV = findViewById(R.id.idRVworkouts);
        workoutModalArrayList = new ArrayList<>();

        prepareWorkoutRV();

        getWorkoutData();

    }

    private void getWorkoutData(){


        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises2");
        String currentUser = ParseUser.getCurrentUser().getUsername();
        query.whereEqualTo("username", currentUser);
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                if (e == null){
                    for (int i = 0; i < objects.size(); i++){

                        String workoutName = objects.get(i).getString("workoutName");
                        String exercise = objects.get(i).getString("set1");

                        workoutModalArrayList.add(new WorkoutModal(workoutName, exercise));
                    }
                    WorkoutRVadapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(MyWorkouts.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



    private void prepareWorkoutRV(){

        workoutsRV.setHasFixedSize(true);
        workoutsRV.setLayoutManager(new LinearLayoutManager(this));

        WorkoutRVadapter = new workoutRVadapter(this, workoutModalArrayList);

        workoutsRV.setAdapter(WorkoutRVadapter);
    }
}