package com.example.final_year_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.util.ArrayList;
import java.util.List;

public class MyWorkouts extends AppCompatActivity {

    private RecyclerView workoutsRV;
    private ArrayList<WorkoutModal> workoutModalArrayList;
    private workoutRVadapter WorkoutRVadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_workouts);

        workoutsRV = findViewById(R.id.idRVworkouts);
        workoutModalArrayList = new ArrayList<>();

        prepareWorkoutRV();

        getWorkoutData();

    }

    private void getWorkoutData(){


        ParseQuery<ParseObject> query = ParseQuery.getQuery("exercises2");
        String currentUser = ParseUser.getCurrentUser().getUsername();
        query.whereEqualTo("username", currentUser);
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                if (e == null){
                    for (int i = 0; i < objects.size(); i++){

                        String workoutName = objects.get(i).getString("workoutName");

                        String exercise = objects.get(i).getString("exercise1");
                        String exercise2 = objects.get(i).getString("exercise2");
                        String exercise3 = objects.get(i).getString("exercise3");
                        String exercise4 = objects.get(i).getString("exercise4");
                        String exercise5 = objects.get(i).getString("exercise5");

                        String DBwt1 = objects.get(i).getString("weight1");
                        String DBwt2 = objects.get(i).getString("weight2");
                        String DBwt3 = objects.get(i).getString("weight3");
                        String DBwt4 = objects.get(i).getString("weight4");
                        String DBwt5 = objects.get(i).getString("weight5");

                        String DBs1r1 = objects.get(i).getString("set1");
                        String DBs1r2 = objects.get(i).getString("set2");
                        String DBs1r3 = objects.get(i).getString("set3");
                        String DBs1r4 = objects.get(i).getString("set4");

                        String DBs2r1 = objects.get(i).getString("set5");
                        String DBs2r2 = objects.get(i).getString("set6");
                        String DBs2r3 = objects.get(i).getString("set7");
                        String DBs2r4 = objects.get(i).getString("set8");

                        String DBs3r1 = objects.get(i).getString("set9");
                        String DBs3r2 = objects.get(i).getString("set10");
                        String DBs3r3 = objects.get(i).getString("set11");
                        String DBs3r4 = objects.get(i).getString("set12");

                        String DBs4r1 = objects.get(i).getString("set13");
                        String DBs4r2 = objects.get(i).getString("set14");
                        String DBs4r3 = objects.get(i).getString("set15");
                        String DBs4r4 = objects.get(i).getString("set16");

                        String DBs5r1 = objects.get(i).getString("set17");
                        String DBs5r2 = objects.get(i).getString("set18");
                        String DBs5r3 = objects.get(i).getString("set19");
                        String DBs5r4 = objects.get(i).getString("set20");

                        workoutModalArrayList.add(new WorkoutModal(workoutName, exercise, exercise2, exercise3, exercise4, exercise5, DBwt1, DBwt2, DBwt3, DBwt4, DBwt5, DBs1r1, DBs1r2, DBs1r3, DBs1r4, DBs2r1, DBs2r2, DBs2r3, DBs2r4, DBs3r1, DBs3r2,DBs3r3, DBs3r4, DBs4r1, DBs4r2,DBs4r3, DBs4r4, DBs5r1, DBs5r2,DBs5r3, DBs5r4));
                    }
                    WorkoutRVadapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(MyWorkouts.this, "Fail to get data..", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



    private void prepareWorkoutRV(){

        workoutsRV.setHasFixedSize(true);
        workoutsRV.setLayoutManager(new LinearLayoutManager(this));

        WorkoutRVadapter = new workoutRVadapter(this, workoutModalArrayList);

        workoutsRV.setAdapter(WorkoutRVadapter);
    }
}