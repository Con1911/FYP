package com.example.final_year_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.parse.ParseUser;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText usernameText = (EditText) findViewById(R.id.editText_username);
        EditText passwordText = (EditText) findViewById(R.id.editText_password);
        Button loginButton = (Button) findViewById(R.id.button_signin);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usrName = usernameText.getText().toString();
                String passWord = passwordText.getText().toString();

                if (TextUtils.isEmpty(usrName)) {
                    usernameText.setError("Please enter your username");
                }
                if (TextUtils.isEmpty(passWord)) {
                    passwordText.setError("Please enter your password");
                } else {
                    // calling method to add data to Firebase Firestore.
                    usrLogin(usrName, passWord);
                }

            }
        });

    }


    public void GoToSignUp(View view){
        Intent intent = new Intent(MainActivity.this, SignUpActivity.class);
        startActivity(intent);
    }


    public void usrLogin(String u_name, String p_word){
        ParseUser.logInInBackground(u_name, p_word, (parseUser, e) -> {
            if  (parseUser != null){
                Toast.makeText(MainActivity.this, "Successful Login, Welcome back " + u_name + " !", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                intent.putExtra("Name", u_name);
                startActivity(intent);
            } else {
                ParseUser.logOut();
                Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}