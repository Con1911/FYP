package com.example.final_year_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;

public class EnterInfo extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Button button;
    String trainingType, heightSTR, weightSTR, ageSTR, finalType;
    private EditText heightEdt, weightEdt, ageEdt;
    String tType;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_info);

        CheckBox beginner = (CheckBox)findViewById(R.id.beginnerCheckBox);
        CheckBox advanced = (CheckBox)findViewById(R.id.advancedCheckBox);
        CheckBox day1 = (CheckBox)findViewById(R.id.daysCheckBox3);
        CheckBox day2 = (CheckBox)findViewById(R.id.daysCheckBox4);
        CheckBox day3 = (CheckBox)findViewById(R.id.daysCheckBox6);

        heightEdt = findViewById(R.id.editText_Height);
        weightEdt = findViewById(R.id.editText_Weight);
        ageEdt = findViewById(R.id.editText_Age);




        Spinner spinner2 = findViewById(R.id.spinner_trainingGoals);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.trainingGoals, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);
        spinner2.setOnItemSelectedListener(this);



        button = (Button) findViewById(R.id.button_generateProgram);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String trainingDays = "", trainingExp = "";
                heightSTR = heightEdt.getText().toString();
                weightSTR = weightEdt.getText().toString();
                ageSTR = ageEdt.getText().toString();

                if (TextUtils.isEmpty(heightSTR) || heightSTR.length()<0 || TextUtils.isEmpty(weightSTR) || weightSTR.length()<0 || TextUtils.isEmpty(ageSTR) || ageSTR.length()<0) {
                    if (TextUtils.isEmpty(heightSTR) || heightSTR.length() < 0) {
                        heightEdt.setError("Please enter height in centimetres");
                    }
                    if (TextUtils.isEmpty(weightSTR) || weightSTR.length() < 0) {
                        weightEdt.setError("Please enter weight in kilograms");
                    }
                    if (TextUtils.isEmpty(ageSTR) || ageSTR.length() < 0) {
                        ageEdt.setError("Please enter your age");
                    }
                }else {

                //checks what training experience is picked
                if (beginner.isChecked() && advanced.isChecked()) {
                    Toast.makeText(EnterInfo.this, "Select your type of training experience", Toast.LENGTH_LONG).show();
                    advanced.setChecked(false);
                    beginner.setChecked(false);
                }
                if (beginner.isChecked()){
                    trainingExp = "beginner";
                } else if (advanced.isChecked()) {
                    trainingExp = "advanced";
                }

                //checks whats days are checked
                if (day1.isChecked() && (day2.isChecked() || day3.isChecked()) || day2.isChecked() && day3.isChecked()) {
                    Toast.makeText(EnterInfo.this, "Select one option for the amount of days you would like to train", Toast.LENGTH_LONG).show();
                    day1.setChecked(false);
                    day2.setChecked(false);
                    day3.setChecked(false);
                }
                if (day1.isChecked()) {
                    trainingDays = "3days";
                } else if (day2.isChecked()) {
                    trainingDays = "4days";
                } else if (day3.isChecked()) {
                    trainingDays = "6days";
                }

                if (trainingExp != "" && trainingDays != "") {
                    if ((trainingExp == "beginner") && (trainingDays == "3days") && (tType == "strength")) {
                        addDataToDatabase(heightSTR, weightSTR, ageSTR, trainingType, trainingDays, trainingExp);
                        Intent intent = new Intent(EnterInfo.this, GeneratedProgramWorkouts.class);
                        intent.putExtra("beginner_3days_Strength", true);
                        spinner2.setSelection(0);
                        startActivity(intent);
                    } else if ((trainingExp == "beginner") && (trainingDays == "4days") && (tType == "strength")) {
                        addDataToDatabase(heightSTR, weightSTR, ageSTR, trainingType, trainingDays, trainingExp);
                        Intent intent = new Intent(EnterInfo.this, GeneratedProgramWorkouts.class);
                        intent.putExtra("beginner, 4days, Strength", true);
                        spinner2.setSelection(0);
                        startActivity(intent);
                    } else if ((trainingExp == "beginner") && (trainingDays == "6days") && (tType == "strength")) {
                        Toast.makeText(EnterInfo.this, "Beginners can only train 3 or 4 days a week", Toast.LENGTH_LONG).show();
                    } else if ((trainingExp == "advanced") && (trainingDays == "3days") && (tType == "strength")) {
                        addDataToDatabase(heightSTR, weightSTR, ageSTR, trainingType, trainingDays, trainingExp);
                        Intent intent = new Intent(EnterInfo.this, GeneratedProgramWorkouts.class);
                        intent.putExtra("advanced, 3days, Strength", true);
                        spinner2.setSelection(0);
                        startActivity(intent);
                    } else if ((trainingExp == "advanced") && (trainingDays == "4days") && (tType == "strength")) {
                        addDataToDatabase(heightSTR, weightSTR, ageSTR, trainingType, trainingDays, trainingExp);
                        Intent intent = new Intent(EnterInfo.this, GeneratedProgramWorkouts.class);
                        intent.putExtra("advanced, 4days, Strength", true);
                        spinner2.setSelection(0);
                        startActivity(intent);
                    } else if ((trainingExp == "advanced") && (trainingDays == "6days") && (tType == "strength")) {
                        addDataToDatabase(heightSTR, weightSTR, ageSTR, trainingType, trainingDays, trainingExp);
                        Intent intent = new Intent(EnterInfo.this, GeneratedProgramWorkouts.class);
                        intent.putExtra("advanced, 6days, Strength", true);
                        spinner2.setSelection(0);
                        startActivity(intent);
                    } else if ((trainingExp == "beginner") && (trainingDays == "3days") && (tType == "hypertrophy")) {
                        addDataToDatabase(heightSTR, weightSTR, ageSTR, trainingType, trainingDays, trainingExp);
                        Intent intent = new Intent(EnterInfo.this, GeneratedProgramWorkouts.class);
                        intent.putExtra("beginner, 3days, Hypertrophy", true);
                        spinner2.setSelection(0);
                        startActivity(intent);
                    } else if ((trainingExp == "beginner") && (trainingDays == "4days") && (tType == "hypertrophy")) {
                        addDataToDatabase(heightSTR, weightSTR, ageSTR, trainingType, trainingDays, trainingExp);
                        Intent intent = new Intent(EnterInfo.this, GeneratedProgramWorkouts.class);
                        intent.putExtra("beginner, 4days, Hypertrophy", true);
                        spinner2.setSelection(0);
                        startActivity(intent);
                    } else if ((trainingExp == "beginner") && (trainingDays == "6days") && (tType == "hypertrophy")) {
                        Toast.makeText(EnterInfo.this, "Beginners can only train 3 or 4 days a week", Toast.LENGTH_LONG).show();
                    } else if ((trainingExp == "advanced") && (trainingDays == "3days") && (tType == "hypertrophy")) {
                        addDataToDatabase(heightSTR, weightSTR, ageSTR, trainingType, trainingDays, trainingExp);
                        Intent intent = new Intent(EnterInfo.this, GeneratedProgramWorkouts.class);
                        intent.putExtra("advanced, 3days, Hypertrophy", true);
                        spinner2.setSelection(0);
                        startActivity(intent);
                    } else if ((trainingExp == "advanced") && (trainingDays == "4days") && (tType == "hypertrophy")) {
                        addDataToDatabase(heightSTR, weightSTR, ageSTR, trainingType, trainingDays, trainingExp);
                        Intent intent = new Intent(EnterInfo.this, GeneratedProgramWorkouts.class);
                        intent.putExtra("advanced, 4days, Hypertrophy", true);
                        spinner2.setSelection(0);
                        startActivity(intent);
                    } else if ((trainingExp == "advanced") && (trainingDays == "6days") && (tType == "hypertrophy")) {
                        addDataToDatabase(heightSTR, weightSTR, ageSTR, trainingType, trainingDays, trainingExp);
                        Intent intent = new Intent(EnterInfo.this, GeneratedProgramWorkouts.class);
                        intent.putExtra("advanced, 6days, Hypertrophy", true);
                        spinner2.setSelection(0);
                        startActivity(intent);
                    } else {
                        Toast.makeText(EnterInfo.this, "Please select a training type", Toast.LENGTH_LONG).show();
                    }

                }





                }


                }

            });






    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id){
       trainingType = parent.getItemAtPosition(position).toString();
       finalType = trainingType;
        switch(position)
        {



            case 0:


                //Toast.makeText(parent.getContext(),trainingType, Toast.LENGTH_SHORT).show();
                tType = "strength";
                //tType2 = "pass";

                break;
            case 1:

                //Toast.makeText(parent.getContext(),trainingType, Toast.LENGTH_SHORT).show();

                tType = "hypertrophy";
                //tType2 = "pass";

                break;

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void addDataToDatabase(String heightSTR, String weightSTR, String ageSTR, String trainingType, String trainingDays, String trainingExp) {

        //ParseObject userDetails = new ParseObject("User");
        ParseUser userDetails = ParseUser.getCurrentUser();


        userDetails.put("height", heightSTR);
        userDetails.put("weight", weightSTR);
        userDetails.put("age", ageSTR);
        userDetails.put("trainingDays", trainingDays);
        userDetails.put("trainingType", trainingType);
        userDetails.put("trainingExp", trainingExp);

        userDetails.saveInBackground(new SaveCallback() {
            @Override
            public void done(ParseException e) {

                if (e == null) {


                    // if the error is null we are displaying a simple toast message.
                    Toast.makeText(EnterInfo.this, trainingDays + " " + trainingExp + " " + trainingType, Toast.LENGTH_SHORT).show();

                    // on below line we are setting our edit text fields to empty value.
                    heightEdt.setText("");
                    weightEdt.setText("");
                    ageEdt.setText("");

                } else {
                    // if the error is not null we will be
                    // displaying an error message to our user.
                    //Toast.makeText(getApplicationContext(), e.getMessage().toString(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}