package com.example.final_year_project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.parse.ParseObject;

import java.util.ArrayList;
import java.util.List;

public class workoutRVadapter extends RecyclerView.Adapter<workoutRVadapter.ViewHolder> {
TextView test;
    private Context context;
    private ArrayList<WorkoutModal> workoutModalArrayList;


    public workoutRVadapter(Context context, ArrayList<WorkoutModal> workoutModalArrayList){
        this.context = context;
        this.workoutModalArrayList = workoutModalArrayList;
    }

    @NonNull
    @Override
    public workoutRVadapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.workout_rv_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull workoutRVadapter.ViewHolder holder, int position) {

        WorkoutModal workouts = workoutModalArrayList.get(position);
        holder.workoutNameTV.setText(workouts.getWorkoutName());
        holder.exerciseTV.setText(workouts.getExercise());
        holder.exercise2TV.setText(workouts.getExercise2());
        holder.exercise3TV.setText(workouts.getExercise3());
        holder.exercise4TV.setText(workouts.getExercise4());
        holder.exercise5TV.setText(workouts.getExercise5());

        holder.DBwt1TV.setText(workouts.getDBwt1());
        holder.DBwt1TV.setText(workouts.getDBwt1());
        holder.DBwt2TV.setText(workouts.getDBwt2());
        holder.DBwt3TV.setText(workouts.getDBwt3());
        holder.DBwt4TV.setText(workouts.getDBwt4());
        holder.DBwt5TV.setText(workouts.getDBwt5());

        holder.DBs1r1TV.setText(workouts.getDBs1r1());
        holder.DBs1r2TV.setText(workouts.getDBs1r2());
        holder.DBs1r3TV.setText(workouts.getDBs1r3());
        holder.DBs1r4TV.setText(workouts.getDBs1r4());

        holder.DBs2r1TV.setText(workouts.getDBs2r1());
        holder.DBs2r2TV.setText(workouts.getDBs2r2());
        holder.DBs2r3TV.setText(workouts.getDBs2r3());
        holder.DBs2r4TV.setText(workouts.getDBs2r4());

        holder.DBs3r1TV.setText(workouts.getDBs3r1());
        holder.DBs3r2TV.setText(workouts.getDBs3r2());
        holder.DBs3r3TV.setText(workouts.getDBs3r3());
        holder.DBs3r4TV.setText(workouts.getDBs3r4());

        holder.DBs4r1TV.setText(workouts.getDBs4r1());
        holder.DBs4r2TV.setText(workouts.getDBs4r2());
        holder.DBs4r3TV.setText(workouts.getDBs4r3());
        holder.DBs4r4TV.setText(workouts.getDBs4r4());

        holder.DBs5r1TV.setText(workouts.getDBs5r1());
        holder.DBs5r2TV.setText(workouts.getDBs5r2());
        holder.DBs5r3TV.setText(workouts.getDBs5r3());
        holder.DBs5r4TV.setText(workouts.getDBs5r4());



    }



    @Override
    public int getItemCount() {
        return workoutModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private final TextView workoutNameTV;
        private final TextView exerciseTV;
        private final TextView exercise2TV, exercise3TV, exercise4TV, exercise5TV, DBwt1TV, DBwt2TV, DBwt3TV, DBwt4TV, DBwt5TV, DBs1r1TV, DBs1r2TV, DBs1r3TV, DBs1r4TV, DBs2r1TV, DBs2r2TV, DBs2r3TV, DBs2r4TV, DBs3r1TV, DBs3r2TV, DBs3r3TV, DBs3r4TV, DBs4r1TV, DBs4r2TV,DBs4r3TV, DBs4r4TV, DBs5r1TV, DBs5r2TV,DBs5r3TV, DBs5r4TV;

        public ViewHolder(@NonNull View itemView){
            super(itemView);
            workoutNameTV = itemView.findViewById(R.id.idTVworkoutName);

            exerciseTV = itemView.findViewById(R.id.textViewEx1);
            exercise2TV = itemView.findViewById(R.id.textViewEx2);
            exercise3TV = itemView.findViewById(R.id.textViewEx3);
            exercise4TV = itemView.findViewById(R.id.textViewEx4);
            exercise5TV = itemView.findViewById(R.id.textViewEx5);

            DBwt1TV = itemView.findViewById(R.id.Weight1RV);
            DBwt2TV = itemView.findViewById(R.id.Weight2RV);
            DBwt3TV = itemView.findViewById(R.id.Weight3RV);
            DBwt4TV = itemView.findViewById(R.id.Weight4RV);
            DBwt5TV = itemView.findViewById(R.id.Weight5RV);

            DBs1r1TV = itemView.findViewById(R.id.Set1_1RV);
            DBs1r2TV = itemView.findViewById(R.id.Set1_2RV);
            DBs1r3TV = itemView.findViewById(R.id.Set1_3RV);
            DBs1r4TV = itemView.findViewById(R.id.Set1_4RV);

            DBs2r1TV = itemView.findViewById(R.id.Set2_1RV);
            DBs2r2TV = itemView.findViewById(R.id.Set2_2RV);
            DBs2r3TV = itemView.findViewById(R.id.Set2_3RV);
            DBs2r4TV = itemView.findViewById(R.id.Set2_4RV);

            DBs3r1TV = itemView.findViewById(R.id.Set3_1RV);
            DBs3r2TV = itemView.findViewById(R.id.Set3_2RV);
            DBs3r3TV = itemView.findViewById(R.id.Set3_3RV);
            DBs3r4TV = itemView.findViewById(R.id.Set3_4RV);

            DBs4r1TV = itemView.findViewById(R.id.Set4_1RV);
            DBs4r2TV = itemView.findViewById(R.id.Set4_2RV);
            DBs4r3TV = itemView.findViewById(R.id.Set4_3RV);
            DBs4r4TV = itemView.findViewById(R.id.Set4_4RV);

            DBs5r1TV = itemView.findViewById(R.id.Set5_1RV);
            DBs5r2TV = itemView.findViewById(R.id.Set5_2RV);
            DBs5r3TV = itemView.findViewById(R.id.Set5_3RV);
            DBs5r4TV = itemView.findViewById(R.id.Set5_4RV);



        }
    }
}
